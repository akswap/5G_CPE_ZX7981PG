ZX7981PG Safe SIM1 Auto Profile v2.3.1
====================================

Purpose
-------
Use Jio and Airtel alternately in SIM1 without entering AT commands after
every SIM swap.

Profiles
--------
Jio:
  APN selection: jio / jionet (existing index is detected)
  LTE UCI IPv6: 2 (firmware-normalized Jio IPv6 mode)

Airtel:
  APN selection: airtel / airtelgprs.com (existing index is detected)
  LTE UCI IPv6: 1 (IPv4/IPv6 dual stack)

Vi:
  APN selection: vi (existing profile is detected or created)
  APN: www
  LTE UCI IPv6: 1 (IPv4/IPv6 dual stack)

Safety design
-------------
- Runs once at boot; it is not a 10-second PDP watcher.
- Never runs AT+CGACT and never repeatedly reconnects the PDP context.
- Leaves modem mode preferences untouched; AUTO/0 supports Jio SA and Airtel NSA.
- Changes settings only for detected Jio, Airtel or Vi SIMs.
- AT queries have an 8-second ubus timeout so boot detection cannot hang forever.
- Saves both APN selection and lte.main.apn so the active dialer uses the operator's APN.
- If the persistent profile changes, the router reboots exactly once.
- On the following boot, matching settings cause no reboot.

Expected use
------------
1. Power off the router.
2. Put either Jio or Airtel in SIM1.
3. Power on.
4. After a SIM change, one extra automatic reboot can occur.
5. Wait until the router and internet are fully back.

Status
------
  /usr/bin/sim-profile-onboot --status
  logread -e sim-profile-onboot

The old sa-profile-switch service must remain disabled.
